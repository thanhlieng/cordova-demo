//
//  LivenessSDKNoAuth.h
//  LivenessSDKNoAuth
//
//  Created by Anh Chuong Mascom on 25/6/24.
//

#import <Foundation/Foundation.h>

//! Project version number for LivenessSDKNoAuth.
FOUNDATION_EXPORT double LivenessSDKNoAuthVersionNumber;

//! Project version string for LivenessSDKNoAuth.
FOUNDATION_EXPORT const unsigned char LivenessSDKNoAuthVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LivenessSDKNoAuth/PublicHeader.h>


